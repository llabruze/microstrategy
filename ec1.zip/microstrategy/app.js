//jshint esversion:6
const express = require("express");;
const ejs = require("ejs");
const mongoose = require("mongoose");
const encrypt = require("mongoose-encryption");

const app = express();

app.use("/public", express.static(__dirname + "/public"));
app.set('view engine', 'ejs');
app.use(express.json());
app.use(express.urlencoded({
    extended: true
}));

mongoose.connect("mongodb+srv://admin-strategy:ORangeapple41@cluster0.3ncmn.mongodb.net/userDB", {userNewUrlParser: true});

const userSchema = new mongoose.Schema ({
    email: String,
    password: String
});

const secret = "Thisisourlittlesecret.";
userSchema.plugin(encrypt, { secret: secret, encryptedFields: ["password"] });


const User = new mongoose.model("User", userSchema);


app.get("/", function(request, respond){
    respond.render("home");
});

app.get("/login", function(request, respond){
    respond.render("login");
});

app.get("/register", function(request, respond){
    respond.render("register");
});

app.get("/markets", function(request, respond){
    respond.render("markets");
});

app.get("/settings-wallet", function(request, respond){
    respond.render("settings-wallet");
});

app.get("/settings-profile", function(request, respond){
    respond.render("settings-profile");
});
app.get("/settings", function(request, respond){
    respond.render("settings");
});

app.get("/market-capital", function(request, respond){
    respond.render("market-capital");
});

app.get("/exchange-ticker", function(request, respond){
    respond.render("exchange-ticker");
});

app.get("/about", function(request, respond){
    respond.render("about");
});

app.get("/404", function(request, respond){
    respond.render("404");
});

app.get("/500", function(request, respond){
    respond.render("500");
});

app.get("/contact_us", function(request, respond){
    respond.render("contact_us");
});

app.post("/register", function(request, respond){
const newUser = new User({
    email: request.body.username,
    password: request.body.password
  });
  newUser.save(function(err){
      if (err) {
          console.log(err);
      } else {
          respond.render("exchange");
      }
  });
});


app.post("/login", function(request, respond){
    const username = request.body.username;
    const password = request.body.password;

User.findOne({email: username}, function(err, foundUser){
    if (err) {
        console.log(err);
    } else {
        if (foundUser) {
            if(foundUser.password === password) {
        respond.render("exchange");
    }
    }
  }
 });
});


app.listen(3000, function() {
    console.log("Server started already on port 3000.");
});